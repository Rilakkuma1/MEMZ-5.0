MEMZ 5.0

A most destructive trojan.

Effects will work in Windows versions.